import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
import math

def Centreduire(T):
    T=np.array(T,dtype=np.float64)
    (n,p)=T.shape
    res=np.zeros((n,p))
    TMoy=np.mean(T,axis=0)
    TEcart=np.std(T,axis=0)
    for j in range(p):
        res[:,j]=(T[:,j]-TMoy[j])/TEcart[j]
    return res

def DiagBatons(Colonne,Titre,X,Y):
    m = Colonne.min()# m contient la valeur minimale de la colonne
    M = Colonne.max() # M contient la valeur maximale de la colonne
    inter = np.linspace(m,M,30)# liste de 21 valeurs allant de m`a M.
    #On peut utiliser la fonction np.linspace
    plt.hist(Colonne,inter,histtype='bar',align='left',rwidth=0.5)
    # trace du diagramme pour les intervalles inter
    plt.title(Titre)
    plt.xlabel(X)
    plt.ylabel(Y)
    plt.show()

#On lit le fichier meilleurestat.csv pour obtenir la dataframe du fichier
MeilleureStatDF = pd.read_csv("/home/etuinfo/agandemer/Semestre_2/SAE_2.04/meilleurestat.csv",sep=",")

#On enlève les espaces vides même si, normalement, il n'y en a pas.
MeilleureStatDF = MeilleureStatDF.dropna()

#On transforme ce dataframe en array.
MeilleureStatAr = MeilleureStatDF.to_numpy()

#
MeilleureStatAr0 = MeilleureStatAr[:,1:6]
#On centre-résuit cette array pour faire la covariance.
MeilleureStatAr0_CR = Centreduire(MeilleureStatAr0)

#On affiche sous la forme d'un graphique toutes nos statistiques.
DiagBatons(MeilleureStatAr0[:,0],'Graphe 1','Taux de reussite',"Nombre d'etablissement")
DiagBatons(MeilleureStatAr0[:,1],'Graphe 2','Effectif',"Nombre d'etablissement")
DiagBatons(MeilleureStatAr0[:,2],'Graphe 3',"Total d'eleves faissant lv2 Espagnol","Nombre d'etablissement")
DiagBatons(MeilleureStatAr0[:,3],'Graphe 4','Latitude',"Nombre d'etablissement")
DiagBatons(MeilleureStatAr0[:,4],'Graphe 5',"Nombres de lettres dans le nom de l'etablissement","Nombre d'etablissement")

#On crée une matrice de covariance pour repèrer les variables qui corrèlent.
MatriceCov = np.cov(MeilleureStatAr0_CR,rowvar=False)
print(MatriceCov)

Y = MeilleureStatAr0[:, 0]
X = MeilleureStatAr0[:, [1,2,3,4]]

linear_regression = LinearRegression()
linear_regression.fit(X, Y)
a=linear_regression.coef_
# print(a)

CorS=linear_regression.score(X,Y)
print(math.sqrt(CorS))